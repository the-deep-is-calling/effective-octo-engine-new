from flask import Flask, jsonify
from flask_cors import CORS
from data_simulator import get_weather_data
from alert_engine import compute_alert

app = Flask(__name__)
CORS(app, origins=["http://localhost:8000"])  # allow frontend on 8000


@app.route("/weather", methods=['GET'])
def weather():
    data = get_weather_data()
    alert = compute_alert(data)
    return jsonify({
        "weather": data,
        "alert": alert
    })

#@app.route("/")
#def index():
    #return app.send_static_file("index.html")

if __name__ == "__main__":
    app.run(debug=True, port=8001)